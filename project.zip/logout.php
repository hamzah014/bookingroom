<?php   
session_start();
session_unset(); //destroy the session
session_destroy(); //destroy the session
header("location:login.php"); //to redirect back to "login.php" after logging out
?>