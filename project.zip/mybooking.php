<!DOCTYPE html>
<html lang="en">

    <title>My Booking</title>
<?php include('header.php'); ?>

<?php

	//retrieve all room data from database
	$sql = "select * from booking_room where student_id='$idstudent' order by id";
		
	$details= array();
	$index = 0;
	
	$query = $conn->query($sql) or die($conn->error);
	while($row = $query->fetch_assoc())
	{
		$details[$index] = $row;
		$index++;		
	}
	//print_r($details);

?>

<body class="animsition">
    <div class="page-wrapper">
        <!-- HEADER MOBILE-->
		
        <!-- MENU SIDEBAR-->
        <?php include('left_navigation.php'); ?>
        <!-- END MENU SIDEBAR-->

        <!-- PAGE CONTAINER-->
        <div class="page-container">
            <!-- HEADER DESKTOP-->
            <?php include('top_navigation.php'); ?>
            <!-- HEADER DESKTOP-->
			
            <!-- MAIN CONTENT-->
            <div class="main-content">
                <div class="section__content section__content--p30">
                    <div class="container-fluid">
                        <div class="row">
                            <div class="col-md-12">
								<h1>My Booking List</h1>
                            </div>
                        </div>
						
						<hr>
						
                        <div class="row justify-content-center">
                            <div class="col-md-12">
								
								<!-- DATA TABLE-->
                                <div class="table-responsive table--no-card m-b-30">
                                    <table class="table table-borderless table-striped table-earning">
                                        <thead>
                                            <tr>
                                                <th>No.</th>
                                                <th>Room Name</th>
                                                <th>Date</th>
                                                <th>Time Start</th>
                                                <th>Time End</th>
                                                <th>Remarks</th>
                                                <th></th>
                                            </tr>
                                        </thead>
                                        <tbody>
											
										<?php
										
											//print_r($details);
											if(empty($details)){
												
												//if theres no data matching with student id, then display alert
										?>		
											<tr>
                                                <td colspan="10" class="alert alert-warning text-warning text-center">Sorry, you never make any booking yet.</td>
                                            </tr>	
												
										<?php		
											}else{
												
												//if there is data matching with student id, then display all booking data
												$bil = 0;
												//loop the data and create row for each data
												foreach($details as $key => $value){
													
													$bil++;
													
													$id 			= $value['id'];
													$room 			= $value['room'];
													$datebook 		= $value['datebook'];
													$time_start 	= $value['time_start'];
													$time_end 		= $value['time_end'];
													$remarks 		= $value['remarks'];
													
										?>
										
										
                                            <tr>
                                                <td><?php echo $bil 		; ?></td>
                                                <td><?php echo $room 		; ?></td>
                                                <td><?php echo $datebook 	; ?></td>
                                                <td><?php echo $time_start ; ?></td>
                                                <td><?php echo $time_end ; ?></td>
                                                <td><?php echo $remarks ; ?></td>
                                                <td>
													<span><a class="btn btn-success btn-sm" href="view_booking.php?idbook=<?php echo $id; ?>"><i class="fa fa-book"></i> View</a></span>
													<!--
													<span><button class="btn btn-info btn-sm" ><i class="fa fa-print"></i> Print</button> </span>
													-->
												</td>
                                            </tr>
										
										<?php			
												}
												
												
											}
										
										?>
								
                                        </tbody>
                                    </table>
                                </div>
                                <!-- END DATA TABLE-->
								
								
								
                            </div>
                        </div>
                        
                    </div>
                </div>
            </div>
            <!-- END MAIN CONTENT-->
            <!-- END PAGE CONTAINER-->
        </div>
	
    </div>
	<?php include('footer.php'); ?>
	<?php include('script.php'); ?>
	
</body>

</html>
<!-- end document-->
