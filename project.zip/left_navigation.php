<!-- HEADER MOBILE-->
<header class="header-mobile d-block d-lg-none d-print-none">
    <div class="header-mobile__bar">
        <div class="container-fluid">
            <div class="header-mobile-inner">
                <a class="logo" href="index.php">
                    <img src="images/kuptm.png" alt="CoolAdmin" width="30%" />
                </a>
                <button class="hamburger hamburger--slider" type="button">
                    <span class="hamburger-box">
                        <span class="hamburger-inner"></span>
                    </span>
                </button>
            </div>
        </div>
    </div>
    <nav class="navbar-mobile">
        <div class="container-fluid">
            <ul class="navbar-mobile__list list-unstyled">
                <li>
                    <a href="homepage.php">
                        <i class="fa fa-home"></i>Home</a>
                </li>
				
				<?php
					//if admin was login, display this
					if($access_lvl==1){
				?>		
					
				<li>
					<a href="mybooking.php">
						<i class="fa fa-plus"></i>Add Room</a>
				</li>
					
				<li>
					<a href="list_booking.php">
						<i class="fa fa-list"></i>Booking List</a>
				</li>
					
				<li>
					<a href="mybooking.php">
						<i class="fas fa-pencil-alt"></i>Register Booking</a>
				</li>
					
				<?php		
					}else if($access_lvl==2){
					
				?>
				
                      <li>
                          <a href="booking_room.php">
                              <i class="fas fa-pencil-alt"></i>Booking Room</a>
                      </li>
				<li>
					<a href="mybooking.php">
						<i class="fa fa-book"></i>My Booking</a>
				</li>
				
				<?php		
					}
					
				?>
				
                <li>
                    <a href="roomlist.php">
						<i class="fas fa fa-book"></i>Room List</a>
                </li>
				
            </ul>
        </div>
    </nav>
</header>
<!-- END HEADER MOBILE-->
<aside class="menu-sidebar d-none d-lg-block d-print-none">
            <div class="logo">
                <a href="#">
                    <img src="images/kuptm.png" alt="KUPTMKL" />
                </a>
            </div>
            <div class="menu-sidebar__content js-scrollbar1">
                <nav class="navbar-sidebar">
                    <ul class="list-unstyled navbar__list">
                        <li>
                            <a href="homepage.php">
                                <i class="fa fa-home"></i>Home</a>
                        </li>
						
						<?php
							//if admin was login, display this
							if($access_lvl==1){
						?>		
							
						<li>
							<a href="add_room.php">
								<i class="fa fa-plus"></i>Add Room</a>
						</li>
							
						<li>
							<a href="list_booking.php">
								<i class="fa fa-list"></i>Booking List</a>
						</li>
							
						<li>
							<a href="list_booking.php">
								<i class="fas fa-pencil-alt"></i>Register Booking</a>
						</li>
							
						<?php		
							}else if($access_lvl==2){
							
						?>
						
                        <li>
                            <a href="booking_room.php">
                                <i class="fas fa-pencil-alt"></i>Booking Room</a>
                        </li>
						<li>
							<a href="mybooking.php">
								<i class="fa fa-book"></i>My Booking</a>
						</li>
						
						<?php		
							}
							
						?>
						
                        <li>
                            <a href="roomlist.php">
                                <i class="fas fa fa-book"></i>Room List</a>
                        </li>
						
                    </ul>
                </nav>
            </div>
        </aside>