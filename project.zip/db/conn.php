<?php
$dbhost='localhost';
$dbuser='root';
$dbpass='';
$dbname='booking_room';

$conn = mysqli_connect($dbhost,$dbuser,$dbpass,$dbname);

mysqli_select_db($conn,$dbname);

// Check connection
if (mysqli_connect_errno())
{
echo "Failed to connect to MySQL: " . mysqli_connect_error();
}

?>
