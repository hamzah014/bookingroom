<!DOCTYPE html>
<html lang="en">

    <title>Edit Room</title>
	<?php include('header.php'); ?>

	<?php
		
		//check whether this file is GET any room_id
		if( isset($_GET['room_id']) ){
			
			$room_id = $_GET['room_id'];
			//echo $room_id;
			
			//retrieve all room data from database
			$sql = "select * from room where id='$room_id' AND status='Active' order by id";
				
			$details= array();
			$index = 0;
			
			$query = $conn->query($sql) or die($conn->error);
			while($row = $query->fetch_assoc())
			{
				$rooms = $row;
				$index++;		
			}
			//print_r($rooms);
		
		}else{
			
			echo '<script>window.location="homepage.php"</script>';
			
		}
	
	?>


<body class="animsition">
    <div class="page-wrapper">
        <!-- HEADER MOBILE-->
		
        <!-- MENU SIDEBAR-->
        <?php include('left_navigation.php'); ?>
        <!-- END MENU SIDEBAR-->

        <!-- PAGE CONTAINER-->
        <div class="page-container">
            <!-- HEADER DESKTOP-->
            <?php include('top_navigation.php'); ?>
            <!-- HEADER DESKTOP-->
			
            <!-- MAIN CONTENT-->
            <div class="main-content">
                <div class="section__content section__content--p30">
                    <div class="container-fluid">
                        <div class="row">
                            <div class="col-md-12">
								<h1>Edit Room</h1>
                            </div>
                        </div>
						<br>
						<br>
                        <div class="row justify-content-center">
                            <div class="col-lg-10">
                                <div class="card">
                                    <div class="card-header">Register Form</div>
                                    <div class="card-body">
										<?php
											
											if(empty($rooms)){
												
												print "<div class='alert alert-danger text-center'>Sorry we can't find the records.</div>";
												
											}else{
												
												$room_id = $rooms['id'];
												$room_name = $rooms['room_name'];
												$remarks = $rooms['remarks'];
												$room_img = $rooms['room_img'];
												
												$dir = "images/room/";
										
										?>
                                        <div class="card-title">
                                            <h3 class="text-center title-2">Please fill up the form. </h3>
                                        </div>
                                        <hr>
                                        <form action="update_room.php" method="post" enctype="multipart/form-data">
                                            <div class="form-group">
                                                <label for="name" class="control-label mb-1">Room Name</label>
                                                <input id="name" name="room_name" type="text" class="form-control" aria-required="true" aria-invalid="false" required value="<?php echo $room_name; ?>">
                                            </div>
                                            <div class="form-group" hidden>
                                                <label for="name" class="control-label mb-1"></label>
                                                <input id="name" name="room_id" type="text" class="form-control" aria-required="true" aria-invalid="false" required value="<?php echo $room_id; ?>">
                                            </div>
                                            <div class="form-group">
                                                <label for="name" class="control-label mb-1">Remarks</label>
                                                <input name="remarks" type="text" class="form-control" aria-required="true" aria-invalid="false" required value="<?php echo $remarks; ?>">
                                            </div>
                                            <div class="form-group">
                                                <label for="name" class="control-label mb-1">Room Picture</label>
                                                <input name="room_img" id="room_img" type="file" class="form-control" aria-required="true" aria-invalid="false" accept="image/x-png,image/gif,image/jpeg" >
                                            </div>
                                            <div class="form-group">
                                                <div class="row justify-content-center" id="preview_img">
												<!-- display image that have been selected in input for file -->
												<?php
													if($room_img != ""){
												?>
												<img src="<?php echo $dir . $room_img; ?>" alt="Room Image" class="img-fluid" width="300" height="300"/>
												<?php
													}
												?>
												</div>
                                            </div>
                                            <div>
                                                <button id="payment-button" name="submit" type="submit" class="btn btn-lg btn-info btn-block">
                                                    <i class="fa fa-check fa-lg"></i>&nbsp;
                                                    <span id="payment-button-amount">Update</span>
                                                </button>
                                            </div>
                                        </form>
										
										<?php
										
											}
										
										?>
										
										
                                    </div>
                                </div>
                            </div>
                        </div>
                        
                    </div>
                </div>
            </div>
            <!-- END MAIN CONTENT-->
            <!-- END PAGE CONTAINER-->
        </div>
	
    </div>
	<?php include('footer.php'); ?>
	<?php include('script.php'); ?>
	
</body>

<script>
	
	//preview selected image
	function filepreview(input){
	
		if(input.files && input.files[0]){
			var reader = new FileReader();
			reader.onload = function (e){
				$('#preview_img + img').remove();
				$('#preview_img').html('<img src="'+ e.target.result +'" alt="profile_img" class="img-fluid" width="300" height="300"/>');
			}
			reader.readAsDataURL(input.files[0]);
		}
	
	}
	
	$('#room_img').change(function(){
		filepreview(this);
	});


</script>



</html>
<!-- end document-->
