
<!DOCTYPE html>
<html lang="en">

    <title>Validate Booking</title>
<?php include('header.php'); ?>

<?php

	//retrieve data where booking_room table, id = to idbook that we get from previous page.
	if( (isset($_GET['idbook']))){
		
		//print 'yes';
		
		$idbook = $_GET['idbook'];  //defined variable to data that we get just now.
		
		$sql = "select * from booking_room where id='$idbook' order by id";
		
		$details= array();
		$index = 0;
		
		$query = $conn->query($sql) or die($conn->error);
		while($row = $query->fetch_assoc())
		{
			$details = $row; //store all data booking_room that matched with id
		}
		
		
		
		//check if there is data that macthed with the id above.
		if(empty($details)){
			
			print '<script>alert("Sorry, we cant find matched record.")</script>';
			print '<script>window.history.back();</script>';
			
		}else{
			
			//print_r($details);   //display array data of booking room that matched above
			$studentid 		= $details['student_id'];
			$room 			= $details['room'];
			$datebook 		= $details['datebook'];
			$time_start 	= $details['time_start'];
			$time_end 		= $details['time_end'];
			$remarks 		= $details['remarks'];
			
			//find user's name by searching with their student ID
			$sql2 = "select * from student where student_id='$studentid' order by id";
		
			$student= array();
			$index = 0;
			
			$query = $conn->query($sql2) or die($conn->error);
			while($row = $query->fetch_assoc())
			{
				$student = $row; //store all data student that matched with id
			}
			
			$name = $student['name'];
			
			
			
		}
		
	} else {
			//echo "Error: " . $sql_insert . "<br>" . $conn->error;
			print '<script>window.history.back();</script>';
	}
				//print "success";
				
?>				

<body class="animsition">
    <div class="page-wrapper">
        <!-- HEADER MOBILE-->
		
        <!-- MENU SIDEBAR-->
        <?php include('left_navigation.php'); ?>
        <!-- END MENU SIDEBAR-->

        <!-- PAGE CONTAINER-->
        <div class="page-container">
            <!-- HEADER DESKTOP-->
            <?php include('top_navigation.php'); ?>
            <!-- HEADER DESKTOP-->
			
            <!-- MAIN CONTENT-->
            <div class="main-content">
                <div class="section__content section__content--p30">
                    <div class="container-fluid">
                        <div class="row justify-content-center d-print-block" hidden>
                            <div class="col-md-10">
								<img src="images/kuptm.png" alt="KUPTMKL">
                            </div>
                        </div>
                        <div class="row">
                            <div class="col-md-12">
								<h2 class="alert alert-success">Your booking have been successfully send to Administrator.</h2>
                            </div>
                        </div>
						<br><br>
                        <div class="row justify-content-center">
                            <div class="col-lg-10">
                                <div class="card">
                                    <div class="card-header">Booking Form</div>
                                    <div class="card-body">
                                        <hr>
                                        <form action="validate_booking.php" method="post">
                                            <div class="form-group">
                                                <label for="name" class="control-label mb-1">Name</label>
                                                <input id="name" name="name" type="text" class="form-control" aria-required="true" aria-invalid="false" readonly value="<?php echo $name; ?>" required>
                                            </div>
                                            <div class="form-group">
                                                <label for="name" class="control-label mb-1">Student ID</label>
                                                <input id="studentid" name="studentid" type="text" class="form-control" aria-required="true" aria-invalid="false" readonly value="<?php echo $idstudent; ?>" required>
                                            </div>
                                            <div class="form-group">
                                                <label for="name" class="control-label mb-1">Choose Room</label>
                                                <input id="room" name="room" type="text" class="form-control" aria-required="true" aria-invalid="false" required readonly value="<?php echo $room; ?>">
                                            </div>
                                            <div class="form-group">
                                                <label for="name" class="control-label mb-1">Date</label>
                                                <input id="datebook" name="datebook" type="date" class="form-control" aria-required="true" aria-invalid="false" required readonly value="<?php echo $datebook; ?>">
                                            </div>
                                            <div class="row">
                                                <div class="col-6">
                                                    <div class="form-group">
                                                        <label for="cc-exp" class="control-label mb-1">Time Start</label>
                                                        <input id="time_start" name="time_start" type="time" class="form-control" aria-required="true" aria-invalid="false" required min="08:00" max="17:00" readonly value="<?php echo $time_start; ?>">
                                                    </div>
                                                </div>
                                                <div class="col-6">
                                                    <label for="x_card_code" class="control-label mb-1">Time End</label>
                                                    <input id="time_end" name="time_end" type="time" class="form-control" aria-required="true" aria-invalid="false" required  min="08:00" max="17:00" readonly value="<?php echo $time_end; ?>">
                                                </div>
                                            </div>
											<div class="form-group">
                                                <label for="name" class="control-label mb-1">Remarks</label>
                                                <textarea name="remarks" id="remarks" rows="9" placeholder="Remarks for booking room." class="form-control" readonly><?php echo $remarks; ?></textarea>
                                            </div>
                                        </form>
										<div class="d-print-none">
                                            <button id="payment-button" class="btn btn-lg btn-info btn-block" onclick="window.print()">
                                                <i class="fa fa-print fa-lg"></i>&nbsp;
                                                <span id="payment-button-amount">Print Form</span>
                                            </button>
                                        </div>
										<div class="text-center justify-content-center d-print-block" hidden>
                                            <h4>*** Note : Please bring this form with you on your booking date. Thank you. ****</h4>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                        
                    </div>
                </div>
            </div>
            <!-- END MAIN CONTENT-->
            <!-- END PAGE CONTAINER-->
        </div>
	
    </div>
	<?php include('footer.php'); ?>
	<?php include('script.php'); ?>
	
</body>
				
				


</html>
<!-- end document-->
