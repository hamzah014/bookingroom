<?php
	
	print_r($_POST);

?>

<!DOCTYPE html>
<html lang="en">

    <title>Edit Room</title>
	<?php include('header.php'); ?>



<body class="animsition">
    <div class="page-wrapper">
        <!-- HEADER MOBILE-->
		
        <!-- MENU SIDEBAR-->
        <?php include('left_navigation.php'); ?>
        <!-- END MENU SIDEBAR-->

        <!-- PAGE CONTAINER-->
        <div class="page-container">
            <!-- HEADER DESKTOP-->
            <?php include('top_navigation.php'); ?>
            <!-- HEADER DESKTOP-->
			
            <!-- MAIN CONTENT-->
            <div class="main-content">
                <div class="section__content section__content--p30">
                    <div class="container-fluid">
                        <div class="row">
                            <div class="col-md-12">
								<h1>Edit Room</h1>
                            </div>
                        </div>
						<br>
						<br>
                        <div class="row justify-content-center">
                            <div class="col-lg-10">
                                <div class="card">
                                    <div class="card-header">Register Form</div>
                                    <div class="card-body">
										<?php
											
											if( isset($_POST['submit'])){
												
												$room_id 	= $_POST['room_id'];
												$room_name  = $_POST['room_name'];
												$remarks 	= $_POST['remarks'];
												//$room_img 	= $_POST['room_img'];
												
												$dir = "images/room/";
												
												//update all the changes to database
												$sql_update = "UPDATE room SET room_name='$room_name',remarks='$remarks' WHERE id='$room_id'";
												
												if ($conn->query($sql_update) === TRUE) {
													//echo 'success';
													//echo "<center>Note : <b>Existing Record , Updated Successfully</b></center>";
													print "<div class='alert alert-success text-center'>Your data have been successfully updated.</div>";
												
												} else {
													echo "Error: " . $sql_update . "<br>" . $conn->error;
												}
												
												//if there is changes in picture, update again
												if(empty($_FILES['room_img'])){
													
												}else{
													
													$dir = "images/room/";
													
													$target_file = $dir . basename($_FILES["room_img"]["name"]);
													
													//get extension for the image, example jpg,png
													$ext = strtolower(pathinfo($target_file,PATHINFO_EXTENSION));
													
													//rename image that going to be upload in folder
													$rename = $room_name . date("d-m-Y-his") . rand(100,999) .  "." . $ext ;
													
													//move the image into the file
													if (move_uploaded_file($_FILES["room_img"]["tmp_name"], $dir . $rename)) {
														
														//echo "The file ". basename( $_FILES["room_img"]["name"]). " has been uploaded.";
														
														$sql_update2 = "UPDATE room SET room_img='$rename' WHERE id='$room_id'";
												
														if ($conn->query($sql_update2) === TRUE) {
															//echo 'success';
															//echo "<center>Note : <b>Existing Record , Updated Successfully</b></center>";
															print "<div class='alert alert-success text-center'>Your image have been successfully updated.</div>";
														
														} else {
															echo "Error: " . $sql_update2 . "<br>" . $conn->error;
														}
														
														
														
													} else {
														
														
													
													}
													
													
												}
											
										
										?>
                                        <div class="card-title">
                                            <h3 class="text-center title-2">Please fill up the form. </h3>
                                        </div>
                                        <hr>
                                        <form action="update_room.php" method="post" enctype="multipart/form-data">
                                            <div class="form-group">
                                                <label for="name" class="control-label mb-1">Room Name</label>
                                                <input id="name" name="room_name" type="text" class="form-control" aria-required="true" aria-invalid="false" required value="<?php echo $room_name; ?>">
                                            </div>
                                            <div class="form-group" hidden>
                                                <label for="name" class="control-label mb-1"></label>
                                                <input id="name" name="room_id" type="text" class="form-control" aria-required="true" aria-invalid="false" required value="<?php echo $room_id; ?>">
                                            </div>
                                            <div class="form-group">
                                                <label for="name" class="control-label mb-1">Remarks</label>
                                                <input name="remarks" type="text" class="form-control" aria-required="true" aria-invalid="false" required value="<?php echo $remarks; ?>">
                                            </div>
                                            <div class="form-group">
                                                <label for="name" class="control-label mb-1">Room Picture</label>
                                                <input name="room_img" id="room_img" type="file" class="form-control" aria-required="true" aria-invalid="false" accept="image/x-png,image/gif,image/jpeg" >
                                            </div>
                                            <div class="form-group">
                                                <div class="row justify-content-center" id="preview_img">
												<!-- display image that have been selected in input for file -->
												<?php
													if(empty($_FILES['room_img'])){
														
														$room_img = $_FILES['room_img']
														
												?>
												<img src="<?php echo $dir . $room_img; ?>" alt="Room Image" class="img-fluid" width="300" height="300"/>
												<?php
													}
												?>
												</div>
                                            </div>
                                            <div>
                                                <button id="payment-button" name="submit" type="submit" class="btn btn-lg btn-info btn-block">
                                                    <i class="fa fa-check fa-lg"></i>&nbsp;
                                                    <span id="payment-button-amount">Update</span>
                                                </button>
                                            </div>
                                            <div>
                                                <a id="payment-button" class="btn btn-lg btn-warning btn-block" href="roomlist.php">
                                                    <i class="fa fa-arrow-left fa-lg"></i>&nbsp;
                                                    <span id="payment-button-amount">Back to List</span>
                                                </a>
                                            </div>
                                        </form>
										
										<?php
										
											}else{
												
												print "<div class='alert alert-danger text-center'>Sorry we can't find the records.</div>";
												
											}
										
										?>
										
										
                                    </div>
                                </div>
                            </div>
                        </div>
                        
                    </div>
                </div>
            </div>
            <!-- END MAIN CONTENT-->
            <!-- END PAGE CONTAINER-->
        </div>
	
    </div>
	<?php include('footer.php'); ?>
	<?php include('script.php'); ?>
	
</body>

<script>
	
	//preview selected image
	function filepreview(input){
	
		if(input.files && input.files[0]){
			var reader = new FileReader();
			reader.onload = function (e){
				$('#preview_img + img').remove();
				$('#preview_img').html('<img src="'+ e.target.result +'" alt="profile_img" class="img-fluid" width="300" height="300"/>');
			}
			reader.readAsDataURL(input.files[0]);
		}
	
	}
	
	$('#room_img').change(function(){
		filepreview(this);
	});


</script>



</html>
<!-- end document-->
