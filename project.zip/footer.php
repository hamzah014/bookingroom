<footer class="d-print-none" style="padding:10px;background-color:black" >
    <div>
        <div class="text-right text-white">
            <p>Copyright © 2019. Designed by <a class="text-warning">Student KUPTMKL</a></p>
        </div>
    </div>
</footer>