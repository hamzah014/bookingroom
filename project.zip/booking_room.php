<!DOCTYPE html>
<html lang="en">

    <title>Dashboard</title>
<?php include('header.php'); ?>

<?php

	//retrieve all room data from database
	$sql = "select * from room order by id";
		
	$data= array();
	$index = 0;
	
	$query = $conn->query($sql) or die($conn->error);
	while($row = $query->fetch_assoc())
	{
		$data_room[$index] = $row;
		$index++;		
	}
	//return $data_room;
	//print_r($data_room); //display all room data from database

?>



<body class="animsition">
    <div class="page-wrapper">
        <!-- HEADER MOBILE-->
		
        <!-- MENU SIDEBAR-->
        <?php include('left_navigation.php'); ?>
        <!-- END MENU SIDEBAR-->

        <!-- PAGE CONTAINER-->
        <div class="page-container">
            <!-- HEADER DESKTOP-->
            <?php include('top_navigation.php'); ?>
            <!-- HEADER DESKTOP-->
			
            <!-- MAIN CONTENT-->
            <div class="main-content">
                <div class="section__content section__content--p30">
                    <div class="container-fluid">
                        <div class="row">
                            <div class="col-md-12">
								<h1>Register Booking Room</h1>
                            </div>
                        </div>
						<br><br>
                        <div class="row justify-content-center">
                            <div class="col-lg-10">
                                <div class="card">
                                    <div class="card-header">Booking Form</div>
                                    <div class="card-body">
                                        <div class="card-title">
                                            <h3 class="text-center title-2">Please fill up the form. </h3>
                                        </div>
                                        <hr>
                                        <form action="validate_booking.php" method="post">
                                            <div class="form-group">
                                                <label for="name" class="control-label mb-1">Name</label>
                                                <input id="name" name="name" type="text" class="form-control" aria-required="true" aria-invalid="false" readonly value="<?php echo $name; ?>" required>
                                            </div>
                                            <div class="form-group">
                                                <label for="name" class="control-label mb-1">Student ID</label>
                                                <input id="studentid" name="studentid" type="text" class="form-control" aria-required="true" aria-invalid="false" readonly value="<?php echo $idstudent; ?>" required>
                                            </div>
                                            <div class="form-group">
                                                <label for="name" class="control-label mb-1">Choose Room</label>
                                                <select name="room" id="room" class="form-control-sm form-control" required>
                                                    <option value="">Please select</option>
													<?php
														
														foreach($data_room as $key => $value){
															
															$id = $value['id'];
															$name = $value['room_name'];
															
															echo '<option value="'.$name.'">'.strtoupper($name).'</option>';
															
														}
													
													?>
                                                </select>
                                            </div>
                                            <div class="form-group">
                                                <label for="name" class="control-label mb-1">Date</label>
                                                <input id="datebook" name="datebook" type="date" class="form-control" aria-required="true" aria-invalid="false" required>
                                            </div>
                                            <div class="row">
                                                <div class="col-6">
                                                    <div class="form-group">
                                                        <label for="cc-exp" class="control-label mb-1">Time Start</label>
                                                        <input id="time_start" name="time_start" type="time" class="form-control" aria-required="true" aria-invalid="false" required min="08:00" max="17:00">
                                                    </div>
                                                </div>
                                                <div class="col-6">
                                                    <label for="x_card_code" class="control-label mb-1">Time End</label>
                                                    <input id="time_end" name="time_end" type="time" class="form-control" aria-required="true" aria-invalid="false" required  min="08:00" max="17:00">
                                                </div>
                                            </div>
											<div class="form-group">
                                                <label for="name" class="control-label mb-1">Remarks</label>
                                                <textarea name="remarks" id="remarks" rows="9" placeholder="Remarks for booking room." class="form-control"></textarea>
                                            </div>
                                            <div>
                                                <button id="payment-button" type="submit" class="btn btn-lg btn-info btn-block">
                                                    <i class="fa fa-lock fa-lg"></i>&nbsp;
                                                    <span id="payment-button-amount">Booking</span>
                                                </button>
                                            </div>
                                        </form>
                                    </div>
                                </div>
                            </div>
                        </div>
                        
                    </div>
                </div>
            </div>
            <!-- END MAIN CONTENT-->
            <!-- END PAGE CONTAINER-->
        </div>
	
    </div>
	<?php include('footer.php'); ?>
	<?php include('script.php'); ?>
	
</body>

<script>
	
	$( document ).ready(function() {
		
		var today = new Date();
		var dd = today.getDate()+1;
		var mm = today.getMonth()+1; //January is 0!
		var yyyy = today.getFullYear();
		
		if(dd<10){
				dd='0'+dd
			} 
			if(mm<10){
				mm='0'+mm
			} 
		
		today = yyyy+'-'+mm+'-'+dd;
		
		document.getElementById("datebook").setAttribute("min", today);
		
	});


</script>



</html>
<!-- end document-->
