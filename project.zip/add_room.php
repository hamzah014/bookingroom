<!DOCTYPE html>
<html lang="en">

    <title>Add Room</title>
<?php include('header.php'); ?>




<body class="animsition">
    <div class="page-wrapper">
        <!-- HEADER MOBILE-->
		
        <!-- MENU SIDEBAR-->
        <?php include('left_navigation.php'); ?>
        <!-- END MENU SIDEBAR-->

        <!-- PAGE CONTAINER-->
        <div class="page-container">
            <!-- HEADER DESKTOP-->
            <?php include('top_navigation.php'); ?>
            <!-- HEADER DESKTOP-->
			
            <!-- MAIN CONTENT-->
            <div class="main-content">
                <div class="section__content section__content--p30">
                    <div class="container-fluid">
                        <div class="row">
                            <div class="col-md-12">
								<h1>Add Room</h1>
                            </div>
                        </div>
						<br>
						
						<!--////////////////////////////////////////////////// start php process ////////////////////////////////////// -->
						
						<?php
							
							//if( (isset($_POST['room_name'])) && (isset($_POST['remarks'])) && (isset($_FILES['room_img'])) ){
							if( (isset($_POST['submit'])) ){
								
								//echo 'yes';
								$room_name	 = $_POST['room_name'];		//defined all variable that get from form.
								$remarks 	 = $_POST['remarks'];       //defined all variable that get from form.
								$room_img	 = $_FILES['room_img'];     //defined all variable that get from form.
								
								//direction when the image is going to be saved.
								$dir = "images/room/";
								
								//set result by 1, so that it can be used to detect any error in uploading file.
								$result		 = 1;  // 1 = no-error  ;  0 = error
								
								$target_file = $dir . basename($_FILES["room_img"]["name"]);
								
								
								//get extension for the image, example jpg,png
								$ext = strtolower(pathinfo($target_file,PATHINFO_EXTENSION));
								
								//rename image that going to be upload in folder
								$rename = $room_name . date("d-m-Y-his") . rand(100,999) .  "." . $ext ;
								
								// Check if file already exists
								if (file_exists($dir . $rename)) {
									echo "Sorry, file already exists.";
									$result = 0;
								}
								
								// if $result=0, then data is not going to insert.
								if ($result == 0) {
									
									print "<div class='alert alert-danger text-center'>Sorry there an error while insert your data.</div>";
								
								
								// if everything is ok, try to upload file
								} else {
									if (move_uploaded_file($_FILES["room_img"]["tmp_name"], $dir . $rename)) {
										
										//echo "The file ". basename( $_FILES["room_img"]["name"]). " has been uploaded.";
										
										$sql_insert = "INSERT INTO room(room_img,room_name,remarks ) VALUES ('$rename','$room_name','$remarks' )";
										
										//print "<br />" . $sql_insert;
										if ($conn->query($sql_insert) === TRUE) {
												
												print "<div class='alert alert-success text-center'>Room have been successfully added.</div>";
												
										} else {
												//echo "Error: " . $sql_insert . "<br>" . $conn->error;
												print "<div class='alert alert-danger text-center'>Sorry there an error while insert your data.</div>";
										}
										
										
										
									} else {
										
										print "<div class='alert alert-danger text-center'>Sorry there an error while insert your data.</div>";
									
									}
								}
								
								
							}else{
								//echo 'no';
							}
							
							
							
							
						?>
						
						<!-- ////////////////////////////////////////////////// end php process ////////////////////////////////////// -->
						
						<br>
                        <div class="row justify-content-center">
                            <div class="col-lg-10">
                                <div class="card">
                                    <div class="card-header">Register Form</div>
                                    <div class="card-body">
                                        <div class="card-title">
                                            <h3 class="text-center title-2">Please fill up the form. </h3>
                                        </div>
                                        <hr>
                                        <form action="add_room.php" method="post" enctype="multipart/form-data">
                                            <div class="form-group">
                                                <label for="name" class="control-label mb-1">Room Name</label>
                                                <input id="name" name="room_name" type="text" class="form-control" aria-required="true" aria-invalid="false" required>
                                            </div>
                                            <div class="form-group">
                                                <label for="name" class="control-label mb-1">Remarks</label>
                                                <input name="remarks" type="text" class="form-control" aria-required="true" aria-invalid="false" required>
                                            </div>
                                            <div class="form-group">
                                                <label for="name" class="control-label mb-1">Room Picture</label>
                                                <input name="room_img" id="room_img" type="file" class="form-control" aria-required="true" aria-invalid="false" required accept="image/x-png,image/gif,image/jpeg" >
                                            </div>
                                            <div class="form-group">
                                                <div class="row justify-content-center" id="preview_img">
												<!-- display image that have been selected in input for file -->
												</div>
                                            </div>
                                            <div>
                                                <button id="payment-button" name="submit" type="submit" class="btn btn-lg btn-info btn-block">
                                                    <i class="fa fa-plus fa-lg"></i>&nbsp;
                                                    <span id="payment-button-amount">Booking</span>
                                                </button>
                                            </div>
                                        </form>
                                    </div>
                                </div>
                            </div>
                        </div>
                        
                    </div>
                </div>
            </div>
            <!-- END MAIN CONTENT-->
            <!-- END PAGE CONTAINER-->
        </div>
	
    </div>
	<?php include('footer.php'); ?>
	<?php include('script.php'); ?>
	
</body>

<script>
	
	//preview selected image
	function filepreview(input){
	
		if(input.files && input.files[0]){
			var reader = new FileReader();
			reader.onload = function (e){
				$('#preview_img + img').remove();
				$('#preview_img').html('<img src="'+ e.target.result +'" alt="profile_img" class="img-fluid" width="300" height="300"/>');
			}
			reader.readAsDataURL(input.files[0]);
		}
	
	}
	
	$('#room_img').change(function(){
		filepreview(this);
	});


</script>



</html>
<!-- end document-->
