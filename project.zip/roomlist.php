<!DOCTYPE html>
<html lang="en">

    <title>My Booking</title>
<?php include('header.php'); ?>

<?php

	//retrieve all room data from database
	$sql = "select * from room where status='Active' order by id";
		
	$details= array();
	$index = 0;
	
	$query = $conn->query($sql) or die($conn->error);
	while($row = $query->fetch_assoc())
	{
		$rooms[$index] = $row;
		$index++;		
	}
	//print_r($rooms);

?>

<body class="animsition">
    <div class="page-wrapper">
        <!-- HEADER MOBILE-->
		
        <!-- MENU SIDEBAR-->
        <?php include('left_navigation.php'); ?>
        <!-- END MENU SIDEBAR-->

        <!-- PAGE CONTAINER-->
        <div class="page-container">
            <!-- HEADER DESKTOP-->
            <?php include('top_navigation.php'); ?>
            <!-- HEADER DESKTOP-->
			
            <!-- MAIN CONTENT-->
            <div class="main-content">
                <div class="section__content section__content--p30">
                    <div class="container-fluid">
                        <div class="row">
                            <div class="col-md-12">
								<h1>Room List</h1>
                            </div>
                        </div>
						
						<hr>
						
						
                        <div class="row">
                            
							<?php
								
								//print_r($rooms);
								foreach($rooms as $key => $value){
								
									$room_id	 = $value['id'];
									$room_name 	 = $value['room_name'];
									$room_img	 = $value['room_img'];
									$remarks	 = $value['remarks'];
									
									//direction when the image is going to be saved.
									$dir = "images/room/";
									
									if($room_img==""){
										
										$room_img = "room.png";
										
									}else{
										
									}
								
							?>
							
							<div class="col-md-6">
                                <div class="card">
                                    <img class="card-img-top" style="min-width:100%;height:300px" src="<?php echo $dir . $room_img; ?>" alt="Card image cap">
                                    <div class="card-body">
                                        <h4 class="card-title mb-3"><?php echo $room_name; ?></h4>
                                        <p class="card-text">
											<?php echo $remarks; ?>
                                        </p>
                                    </div>
									<div class="card-footer text-center">
                                        <a class="btn btn-info btn-md" href="edit_room.php?room_id=<?php echo $room_id; ?>">Edit</a>
                                        <button class="btn btn-danger btn-md" onclick="deactive()">Deactive</button>
                                    </div>
                                </div>
                            </div>
							<?php
							
								}
							
							?>
                        </div>
						
						
                    </div>
                </div>
            </div>
            <!-- END MAIN CONTENT-->
            <!-- END PAGE CONTAINER-->
        </div>
	
    </div>
	<?php include('footer.php'); ?>
	<?php include('script.php'); ?>
	
</body>


<script>
	
	function deactive(){
		
		var result = confirm('Are you sure want to deactived this room?');
		
		if(result==true){
			alert('okay');
		}else{
			
		}
		
		
	}



</script>


</html>
<!-- end document-->
